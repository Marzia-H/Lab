public class Voldemort{
             public static void main(String[] args)
			 {
			 System.out.println("Tom Marvolo Riddle,later known and feared as Lord Voldemort.");
                         System.out.println("He is the main antagonist of Harry Potter franchise.He is an evil Dark wizard.");
			 }
			 }