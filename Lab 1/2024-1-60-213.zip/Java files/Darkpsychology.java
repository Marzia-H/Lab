public class Darkpsychology{
         public static void main(String[] args){
           System.out.println("Dark psychology refers to the study and application of psychological principles to manipulate, influence,or control people in harmful ways");
          }
                          }
  