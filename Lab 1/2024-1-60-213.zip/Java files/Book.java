public class Book{
         public static void main(String[] args)
		 {
           System.out.println("I have recently readed a book named 'Thinking,Fast and Slow'by psychologist Daniel Kahneman.");
		   System.out.println("The books main thesis is a differentiation between two modes of thought:");
		   System.out.println("First one is fast,instinctive and emotional.");
		   System.out.println("Second one is slower,more deliberative and more logical.");
		   
         }
                          }
  