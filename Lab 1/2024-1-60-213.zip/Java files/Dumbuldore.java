public class Dumbuldore{
             public static void main(String[] args)
			 {
			 System.out.println("He was the Defence Against the Dark Arts Professor,later the Transfiguration Professor.");
                         System.out.println("Also he was the Headmaster of Hogwarts School of Witchcraft and Wizardry.");
			 }
			 }