public class Harrypotter{
             public static void main(String[] args)
			 {
			 System.out.println("Harry Potter is a series of seven fantasy novels written by British author J.K.Rowling.");
			 System.out.println("The novels chronicle the lives of a young wizard,Harry Potter and his friends.");
                         System.out.println("All of them were students at Hogwarts School of Witchcraft and Wizardry.");
			 }
			 }
			 